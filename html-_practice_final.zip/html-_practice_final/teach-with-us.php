<?php
session_start();
require_once 'Config/database.php'; // corrected path

$message = "";
$messageColor = "green";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $experience = trim($_POST['experience']);
    $qualifications = trim($_POST['qualifications']);
    $subject = trim($_POST['subjects']);
    $teaching_mode = trim($_POST['teaching_mode']);
    $introduction = trim($_POST['introduction']);

    // Simple validation
    if (!empty($name) && !empty($email) && !empty($experience) && !empty($qualifications) && !empty($subject)) {

        $database = new Database();
        $db = $database->getConnection();

        $query = "INSERT INTO teachers 
            (name, email, experience, qualifications, subject, teaching_mode, introduction) 
            VALUES 
            (:name, :email, :experience, :qualifications, :subject, :teaching_mode, :introduction)";

        $stmt = $db->prepare($query);
        $stmt->bindParam(":name", $name);
        $stmt->bindParam(":email", $email);
        $stmt->bindParam(":experience", $experience);
        $stmt->bindParam(":qualifications", $qualifications);
        $stmt->bindParam(":subject", $subject);
        $stmt->bindParam(":teaching_mode", $teaching_mode);
        $stmt->bindParam(":introduction", $introduction);

        if ($stmt->execute()) {
            $message = "Application submitted successfully! We will contact you soon.";
            $messageColor = "green";
        } else {
            $message = "Error submitting application.";
            $messageColor = "red";
        }

    } else {
        $message = "Please fill all required fields.";
        $messageColor = "red";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Teach with Us</title>
<style>
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-image: url('./images/background.jpg');
    background-size: cover;
}
form {
    margin: 100px auto;
    width: 450px;
    padding: 40px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    background-color: rgba(255,255,255,0.9);
}
label { display: block; margin-bottom: 8px; font-weight: bold; }
input[type="text"], input[type="email"], textarea {
    width: 100%; padding: 8px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 5px;
}
input[type="submit"] {
    padding: 10px 20px; background-color: green; color: white; border: none; border-radius: 5px; cursor: pointer;
}
input[type="submit"]:hover { background-color: darkgreen; }
h1 { text-align: center; color: #333; margin-bottom: 20px; }
.message { padding: 10px; margin-bottom: 15px; border-radius: 5px; text-align: center; color: white; }
fieldset { margin-bottom: 15px; }
legend { font-weight: bold; }
</style>
</head>
<body>
<form method="POST" action="">
    <h1>Teach with Us</h1>
    <?php if($message != ""): ?>
        <div class="message" style="background-color: <?php echo $messageColor; ?>;">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <label for="name">Full Name:</label>
    <input type="text" id="name" name="name" required>

    <label for="email">Email:</label>
    <input type="email" id="email" name="email" required>

    <label for="experience">Teaching Experience:</label>
    <input type="text" id="experience" name="experience" required>

    <label for="qualifications">Qualifications:</label>
    <input type="text" id="qualifications" name="qualifications" required>

    <label for="subject">Subject To Teach:</label>
    <input type="text" id="subject" name="subjects" required>

    <fieldset>
        <legend>Preferred Teaching Mode:</legend>
        <input type="radio" id="online" name="teaching_mode" value="online" required>
        <label for="online">Online</label>
        <input type="radio" id="in_person" name="teaching_mode" value="in_person">
        <label for="in_person">In-person</label>
    </fieldset>

    <label for="introduction">Introduce Yourself:</label>
    <textarea id="introduction" name="introduction" placeholder="Brief description about yourself"></textarea>

    <input type="submit" value="Submit">
</form>
</body>
</html>