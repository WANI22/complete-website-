<?php
require_once 'config/database.php';

try {

    $database = new Database();
    $conn = $database->getConnection();

    if ($conn) {
        echo "✅ Database connection to 'learnify' successful!";
    } else {
        echo "❌ Database connection failed!";
    }

} catch (Exception $e) {

    echo "Database connection error: " . $e->getMessage();

}
?>