<?php
// admin/edit_course.php

session_start();

require_once '../Config/database.php';

// Check if admin is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();

$message = "";

// Check if course ID exists
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: dashboard.php");
    exit();
}

$id = intval($_GET['id']);


$query = "SELECT * FROM courses WHERE id = :id";

$stmt = $db->prepare($query);
$stmt->bindParam(":id", $id, PDO::PARAM_INT);
$stmt->execute();

$course = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$course) {
    header("Location: dashboard.php");
    exit();
}


// ======================
// UPDATE COURSE
// ======================
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $title = trim($_POST['title']);
    $category = trim($_POST['category']);
    $description = trim($_POST['description']);
    $image_url = trim($_POST['image_url']);

    if (!empty($title) && !empty($category) && !empty($description)) {

        $query = "UPDATE courses
                  SET title = :title,
                      category = :category,
                      description = :description,
                      image_url = :image_url
                  WHERE id = :id";

        $stmt = $db->prepare($query);

        $stmt->bindParam(":title", $title);
        $stmt->bindParam(":category", $category);
        $stmt->bindParam(":description", $description);
        $stmt->bindParam(":image_url", $image_url);
        $stmt->bindParam(":id", $id, PDO::PARAM_INT);

        if ($stmt->execute()) {
            header("Location: dashboard.php?msg=updated");
            exit();
        } else {
            $message = "Error updating course.";
        }

    } else {
        $message = "Please fill all required fields.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Edit Course - KING D ACADEMY</title>

<style>

body{
font-family:Arial;
background:#f4f4f4;
margin:0;
}

.navbar{
background:#1e293b;
color:white;
padding:15px;
display:flex;
justify-content:space-between;
}

.container{
width:600px;
margin:40px auto;
background:white;
padding:30px;
border-radius:10px;
box-shadow:0 4px 6px rgba(0,0,0,0.1);
}

h2{
margin-bottom:20px;
}

input, textarea{
width:100%;
padding:10px;
margin-bottom:15px;
border:1px solid #ccc;
border-radius:5px;
}

textarea{
height:120px;
}

button{
background:#2196f3;
color:white;
border:none;
padding:12px 20px;
border-radius:5px;
cursor:pointer;
font-size:16px;
}

button:hover{
background:#1976d2;
}

.back{
display:inline-block;
margin-top:15px;
text-decoration:none;
color:#333;
}

.message{
background:#f44336;
color:white;
padding:10px;
margin-bottom:15px;
border-radius:5px;
}

</style>

</head>

<body>

<div class="navbar">
<h2>KING D ACADEMY Admin</h2>
<a href="dashboard.php" style="color:white;text-decoration:none;">Dashboard</a>
</div>

<div class="container">

<h2>Edit Course</h2>

<?php if($message != ""): ?>
<div class="message"><?php echo $message; ?></div>
<?php endif; ?>

<form method="POST">

<label>Course Title</label>
<input type="text" name="title" value="<?php echo htmlspecialchars($course['title']); ?>" required>

<label>Category</label>
<input type="text" name="category" value="<?php echo htmlspecialchars($course['category']); ?>" required>

<label>Description</label>
<textarea name="description" required><?php echo htmlspecialchars($course['description']); ?></textarea>

<label>Image URL</label>
<input type="text" name="image_url" value="<?php echo htmlspecialchars($course['image_url']); ?>">

<button type="submit">Update Course</button>

</form>

<a href="dashboard.php" class="back">← Back to Dashboard</a>

</div>

</body>
</html>