<?php
session_start();
require_once '../Config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();

$admin_name = $_SESSION['username'];

// Handle application deletion
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $query = "DELETE FROM teachers WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    header("Location: teacher-applications.php?msg=deleted");
    exit();
}

// Fetch all teacher applications
$query = "SELECT * FROM teachers ORDER BY created_at DESC";
$stmt = $db->prepare($query);
$stmt->execute();
$teachers = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Applications - KING D ACADEMY Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        body {
            background: #f5f7fa;
        }
        .navbar {
            background: linear-gradient(135deg, #1e293b, #0f172a);
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .navbar h1 {
            font-size: 24px;
        }
        .nav-links {
            display: flex;
            gap: 15px;
            align-items: center;
        }
        .nav-links a {
            color: white;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 6px;
        }
        .nav-links a:hover {
            background: rgba(255,255,255,0.1);
        }
        .nav-links .logout {
            background: #f97316;
        }
        .logged-in {
            background: rgba(255,255,255,0.1);
            padding: 8px 16px;
            border-radius: 6px;
            margin-right: 10px;
        }
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }
        .header h1 {
            color: #333;
        }
        .back-btn {
            background: #667eea;
            color: white;
            text-decoration: none;
            padding: 12px 24px;
            border-radius: 8px;
        }
        .message {
            background: #d4edda;
            color: #155724;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
        }
        .applications-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 1.5rem;
        }
        .application-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .application-card h3 {
            color: #333;
            margin-bottom: 15px;
            font-size: 20px;
        }
        .application-card p {
            margin-bottom: 10px;
            color: #666;
        }
        .application-card strong {
            color: #333;
        }
        .mode-badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            background: #e3f2fd;
            color: #1976d2;
            margin-bottom: 15px;
        }
        .application-meta {
            font-size: 12px;
            color: #999;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #eee;
        }
        .actions {
            margin-top: 15px;
        }
        .delete-btn {
            background: #f44336;
            color: white;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 6px;
            font-size: 13px;
        }
        .empty-state {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 12px;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>KING D ACADEMY Admin</h1>
        <div class="nav-links">
            <span class="logged-in">👤 <?php echo htmlspecialchars($admin_name); ?></span>
            <a href="../index.php">View Site</a>
            <a href="dashboard.php">Dashboard</a>
            <a href="../logout.php" class="logout">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <div class="header">
            <h1>Teacher Applications</h1>
            <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
        </div>
        
        <?php if(isset($_GET['msg'])): ?>
            <div class="message">
                <?php echo "✓ Application deleted successfully!"; ?>
            </div>
        <?php endif; ?>
        
        <?php if(count($teachers) > 0): ?>
            <div class="applications-grid">
                <?php foreach($teachers as $teacher): ?>
                    <div class="application-card">
                        <h3><?php echo htmlspecialchars($teacher['name']); ?></h3>
                        <span class="mode-badge"><?php echo htmlspecialchars(ucfirst($teacher['teaching_mode'])); ?></span>
                        
                        <p><strong>Email:</strong> <?php echo htmlspecialchars($teacher['email']); ?></p>
                        <p><strong>Subject:</strong> <?php echo htmlspecialchars($teacher['subject']); ?></p>
                        <p><strong>Experience:</strong> <?php echo htmlspecialchars($teacher['experience']); ?></p>
                        <p><strong>Qualifications:</strong> <?php echo htmlspecialchars($teacher['qualifications']); ?></p>
                        <p><strong>Introduction:</strong> <?php echo htmlspecialchars($teacher['introduction']); ?></p>
                        
                        <div class="application-meta">
                            Applied on: <?php echo date('M d, Y', strtotime($teacher['created_at'])); ?>
                        </div>
                        
                        <div class="actions">
                            <a href="?delete=<?php echo $teacher['id']; ?>" class="delete-btn" onclick="return confirm('Are you sure?')">Delete</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <h3>No teacher applications yet</h3>
                <p>When someone applies to teach, it will appear here.</p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
