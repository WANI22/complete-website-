<?php
session_start();
require_once '../Config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();

$admin_name = $_SESSION['username'];

// Get stats
$query = "SELECT COUNT(*) as count FROM users WHERE role = 'user'";
$stmt = $db->prepare($query);
$stmt->execute();
$user_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

$query = "SELECT COUNT(*) as count FROM courses";
$stmt = $db->prepare($query);
$stmt->execute();
$course_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

$query = "SELECT COUNT(*) as count FROM enrollments";
$stmt = $db->prepare($query);
$stmt->execute();
$enrollment_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

$query = "SELECT COUNT(*) as count FROM teachers";
$stmt = $db->prepare($query);
$stmt->execute();
$teacher_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

// Handle course deletion
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $query = "DELETE FROM courses WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    if ($stmt->execute()) {
        header("Location: dashboard.php?msg=deleted");
        exit();
    }
}

// Fetch all courses
$query = "SELECT c.*, u.username as creator 
          FROM courses c 
          LEFT JOIN users u ON c.created_by = u.id 
          ORDER BY c.created_at DESC";
$stmt = $db->prepare($query);
$stmt->execute();
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - KING D ACADEMY</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        body {
            background: #f5f7fa;
        }
        .navbar {
            background: linear-gradient(135deg, #1e293b, #0f172a);
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        .navbar h1 {
            font-size: 24px;
        }
        .nav-links {
            display: flex;
            gap: 15px;
            align-items: center;
        }
        .nav-links a {
            color: white;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 6px;
            transition: background 0.3s;
        }
        .nav-links a:hover {
            background: rgba(255,255,255,0.1);
        }
        .nav-links .logout {
            background: #f97316;
        }
        .logged-in {
            background: rgba(255,255,255,0.1);
            padding: 8px 16px;
            border-radius: 6px;
            margin-right: 10px;
        }
        .container {
            max-width: 1400px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        .welcome-banner {
            background: linear-gradient(135deg, #1e293b, #0f172a);
            color: white;
            padding: 2rem;
            border-radius: 15px;
            margin-bottom: 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .welcome-banner h2 {
            font-size: 28px;
        }
        .welcome-banner p {
            opacity: 0.9;
            margin-top: 5px;
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .stat-card h3 {
            font-size: 36px;
            margin-bottom: 5px;
        }
        .stat-card p {
            color: #666;
        }
        .stat-card.users h3 { color: #667eea; }
        .stat-card.courses h3 { color: #28a745; }
        .stat-card.enrollments h3 { color: #f97316; }
        .stat-card.teachers h3 { color: #8b5cf6; }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }
        .header h1 {
            color: #333;
        }
        .add-btn {
            background: #28a745;
            color: white;
            text-decoration: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 600;
            transition: background 0.3s;
        }
        .add-btn:hover {
            background: #218838;
        }
        .message {
            background: #d4edda;
            color: #155724;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
        }
        .courses-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 1.5rem;
        }
        .course-card {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .course-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            background: #ddd;
        }
        .course-content {
            padding: 1.5rem;
        }
        .course-title {
            font-size: 18px;
            margin-bottom: 8px;
            color: #333;
        }
        .course-category {
            color: #667eea;
            font-weight: 600;
            margin-bottom: 10px;
        }
        .course-description {
            color: #666;
            margin-bottom: 1rem;
            line-height: 1.5;
        }
        .course-meta {
            font-size: 0.9rem;
            color: #999;
            margin-bottom: 1rem;
        }
        .actions {
            display: flex;
            gap: 10px;
        }
        .edit-btn, .delete-btn {
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 6px;
            font-weight: 600;
            transition: background 0.3s;
        }
        .edit-btn {
            background: #2196f3;
            color: white;
        }
        .edit-btn:hover {
            background: #1976d2;
        }
        .delete-btn {
            background: #f44336;
            color: white;
        }
        .delete-btn:hover {
            background: #d32f2f;
        }
        .no-courses {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 12px;
            color: #666;
        }
        .quick-links {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1rem;
            margin-top: 2rem;
        }
        .quick-link {
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-decoration: none;
            color: #333;
            transition: transform 0.3s;
        }
        .quick-link:hover {
            transform: translateY(-5px);
        }
        .quick-link h4 {
            color: #667eea;
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>KING D ACADEMY Admin</h1>
        <div class="nav-links">
            <span class="logged-in">👤 Logged in as: <?php echo htmlspecialchars($admin_name); ?></span>
            <a href="../index.php">View Site</a>
            <a href="dashboard.php">Dashboard</a>
            <a href="../logout.php" class="logout">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <div class="welcome-banner">
            <div>
                <h2>Welcome back, <?php echo htmlspecialchars($admin_name); ?>!</h2>
                <p>Manage your courses, users, and teacher applications</p>
            </div>
        </div>
        
        <div class="stats">
            <div class="stat-card users">
                <h3><?php echo $user_count; ?></h3>
                <p>Total Users</p>
            </div>
            <div class="stat-card courses">
                <h3><?php echo $course_count; ?></h3>
                <p>Courses</p>
            </div>
            <div class="stat-card enrollments">
                <h3><?php echo $enrollment_count; ?></h3>
                <p>Enrollments</p>
            </div>
            <div class="stat-card teachers">
                <h3><?php echo $teacher_count; ?></h3>
                <p>Teacher Applications</p>
            </div>
        </div>
        
        <div class="quick-links">
            <a href="add_course.php" class="quick-link">
                <h4>➕ Add New Course</h4>
                <p>Create a new course</p>
            </a>
            <a href="manage-users.php" class="quick-link">
                <h4>👥 Manage Users</h4>
                <p>View and manage registered users</p>
            </a>
            <a href="teacher-applications.php" class="quick-link">
                <h4>📝 Teacher Applications</h4>
                <p>Review teacher applications</p>
            </a>
        </div>
        
        <div class="header" style="margin-top: 2rem;">
            <h1>Course Management</h1>
            <a href="add_course.php" class="add-btn">+ Add New Course</a>
        </div>
        
        <?php if(isset($_GET['msg'])): ?>
            <div class="message">
                <?php 
                    if($_GET['msg'] == 'added') echo "✓ Course added successfully!";
                    if($_GET['msg'] == 'updated') echo "✓ Course updated successfully!";
                    if($_GET['msg'] == 'deleted') echo "✓ Course deleted successfully!";
                ?>
            </div>
        <?php endif; ?>
        
        <?php if(count($courses) > 0): ?>
            <div class="courses-grid">
                <?php foreach($courses as $course): ?>
                    <div class="course-card">
                        <?php if($course['image_url']): ?>
                            <img src="<?php echo htmlspecialchars($course['image_url']); ?>" alt="<?php echo htmlspecialchars($course['title']); ?>" class="course-image">
                        <?php else: ?>
                            <div class="course-image" style="background: linear-gradient(135deg, #667eea, #764ba2); display: flex; align-items: center; justify-content: center; color: white; font-size: 48px;">📚</div>
                        <?php endif; ?>
                        <div class="course-content">
                            <h3 class="course-title"><?php echo htmlspecialchars($course['title']); ?></h3>
                            <div class="course-category"><?php echo htmlspecialchars($course['category']); ?></div>
                            <p class="course-description"><?php echo substr(htmlspecialchars($course['description']), 0, 100); ?>...</p>
                            <div class="course-meta">
                                Added by: <?php echo htmlspecialchars($course['creator'] ?: 'Admin'); ?><br>
                                <?php echo date('M d, Y', strtotime($course['created_at'])); ?>
                            </div>
                            <div class="actions">
                                <a href="edit_course.php?id=<?php echo $course['id']; ?>" class="edit-btn">Edit</a>
                                <a href="?delete=<?php echo $course['id']; ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this course?')">Delete</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="no-courses">
                <h2>No courses found</h2>
                <p>Click the "Add New Course" button to create your first course.</p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
