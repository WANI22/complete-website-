<?php
// admin/add_course.php

session_start();

require_once '../Config/database.php';

// Check admin login
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// Connect to database
$database = new Database();
$db = $database->getConnection();

$message = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $title = trim($_POST['title']);
    $category = trim($_POST['category']);
    $description = trim($_POST['description']);
    $image_url = "";
    $created_by = $_SESSION['user_id'];

    // Handle file upload
    if (isset($_FILES['course_image']) && $_FILES['course_image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../images/courses/';
        
        // Create directory if not exists
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_name = $_FILES['course_image']['name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        
        if (in_array($file_ext, $allowed_ext)) {
            $new_file_name = time() . '_' . basename($file_name);
            $target_file = $upload_dir . $new_file_name;
            
            if (move_uploaded_file($_FILES['course_image']['tmp_name'], $target_file)) {
                $image_url = './images/courses/' . $new_file_name;
            }
        }
    } elseif (!empty($_POST['image_url'])) {
        // Use URL if no file uploaded
        $image_url = trim($_POST['image_url']);
    }

    if (!empty($title) && !empty($category) && !empty($description)) {

        $query = "INSERT INTO courses 
                  (title, category, description, image_url, created_by, created_at) 
                  VALUES (:title, :category, :description, :image_url, :created_by, NOW())";

        $stmt = $db->prepare($query);

        $stmt->bindParam(":title", $title);
        $stmt->bindParam(":category", $category);
        $stmt->bindParam(":description", $description);
        $stmt->bindParam(":image_url", $image_url);
        $stmt->bindParam(":created_by", $created_by);

        if ($stmt->execute()) {
            header("Location: dashboard.php?msg=added");
            exit();
        } else {
            $message = "Error adding course.";
        }

    } else {
        $message = "Please fill all required fields.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Add Course - KING D ACADEMY</title>

<style>

body{
font-family:Arial;
background:#f4f4f4;
margin:0;
}

.navbar{
background:#1e293b;
color:white;
padding:15px;
display:flex;
justify-content:space-between;
}

.container{
width:600px;
margin:40px auto;
background:white;
padding:30px;
border-radius:10px;
box-shadow:0 4px 6px rgba(0,0,0,0.1);
}

h2{
margin-bottom:20px;
}

input, textarea{
width:100%;
padding:10px;
margin-bottom:15px;
border:1px solid #ccc;
border-radius:5px;
}

textarea{
height:120px;
}

button{
background:#f97316;
color:white;
border:none;
padding:12px 20px;
border-radius:5px;
cursor:pointer;
font-size:16px;
}

button:hover{
background:#ea580c;
}

.back{
display:inline-block;
margin-top:15px;
text-decoration:none;
color:#333;
}

.message{
background:#f44336;
color:white;
padding:10px;
margin-bottom:15px;
border-radius:5px;
}

</style>

</head>

<body>

<div class="navbar">
<h2>KING D ACADEMY Admin</h2>
<a href="dashboard.php" style="color:white;text-decoration:none;">Dashboard</a>
</div>

<div class="container">

<h2>Add New Course</h2>

<?php if($message != ""): ?>
<div class="message"><?php echo $message; ?></div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data">

<label>Course Title</label>
<input type="text" name="title" required>

<label>Category</label>
<input type="text" name="category" required>

<label>Description</label>
<textarea name="description" required></textarea>

<label>Course Image (Upload from device)</label>
<input type="file" name="course_image" accept="image/*">

<p style="font-size: 12px; color: #666; margin-bottom: 15px;">Or enter image URL below:</p>

<label>Image URL (alternative)</label>
<input type="text" name="image_url" placeholder="https://example.com/image.jpg">

<button type="submit">Add Course</button>

</form>

<a href="dashboard.php" class="back">← Back to Dashboard</a>

</div>

</body>
</html>