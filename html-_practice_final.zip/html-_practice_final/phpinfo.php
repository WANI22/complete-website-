<?php
phpinfo();
?>