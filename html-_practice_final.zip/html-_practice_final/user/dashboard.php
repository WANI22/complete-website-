<?php
session_start();

require_once '../Config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: ../login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

// Get enrolled courses
$query = "SELECT c.*, e.enrolled_at 
          FROM courses c 
          INNER JOIN enrollments e ON c.id = e.course_id 
          WHERE e.user_id = :user_id 
          ORDER BY e.enrolled_at DESC";
$stmt = $db->prepare($query);
$stmt->bindParam(":user_id", $user_id);
$stmt->execute();
$enrolled_courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all available courses
$query = "SELECT * FROM courses ORDER BY created_at DESC";
$stmt = $db->prepare($query);
$stmt->execute();
$all_courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get enrollment count
$query = "SELECT COUNT(*) as count FROM enrollments WHERE user_id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(":user_id", $user_id);
$stmt->execute();
$enrollment_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Dashboard - KING D ACADEMY</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        body {
            background: #f5f7fa;
        }
        .navbar {
            background: linear-gradient(135deg, #20c997 0%, #0ca678 100%);
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        .navbar h1 {
            font-size: 24px;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        .nav-links a {
            color: white;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 6px;
            transition: background 0.3s;
        }
        .nav-links a:hover {
            background: rgba(255,255,255,0.2);
        }
        .nav-links .logout {
            background: #e74c3c;
        }
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        .welcome-banner {
            background: linear-gradient(135deg, #20c997 0%, #0ca678 100%);
            color: white;
            padding: 2rem;
            border-radius: 15px;
            margin-bottom: 2rem;
        }
        .welcome-banner h2 {
            font-size: 28px;
            margin-bottom: 10px;
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }
        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .stat-card h3 {
            color: #667eea;
            font-size: 36px;
            margin-bottom: 5px;
        }
        .stat-card p {
            color: #666;
        }
        .section-title {
            font-size: 24px;
            color: #333;
            margin-bottom: 1.5rem;
            padding-bottom: 10px;
            border-bottom: 3px solid #667eea;
        }
        .courses-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-bottom: 3rem;
        }
        .course-card {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        .course-card:hover {
            transform: translateY(-5px);
        }
        .course-image {
            width: 100%;
            height: 180px;
            object-fit: cover;
            background: #ddd;
        }
        .course-content {
            padding: 1.5rem;
        }
        .course-title {
            font-size: 18px;
            color: #333;
            margin-bottom: 8px;
        }
        .course-category {
            color: #667eea;
            font-weight: 600;
            font-size: 14px;
            margin-bottom: 10px;
        }
        .course-description {
            color: #666;
            font-size: 14px;
            margin-bottom: 15px;
            line-height: 1.5;
        }
        .course-meta {
            font-size: 12px;
            color: #999;
            margin-bottom: 15px;
        }
        .enrolled-badge {
            background: #28a745;
            color: white;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            display: inline-block;
            margin-bottom: 10px;
        }
        .empty-state {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 12px;
        }
        .empty-state h3 {
            color: #666;
            margin-bottom: 10px;
        }
        .empty-state p {
            color: #999;
            margin-bottom: 20px;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: background 0.3s;
        }
        .btn:hover {
            background: #5568d3;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <h1>KING D ACADEMY</h1>
        <div class="nav-links">
            <a href="../index.php">Home</a>
            <a href="dashboard.php">My Courses</a>
            <a href="profile.php">Profile</a>
            <a href="../logout.php" class="logout">Logout</a>
        </div>
    </nav>

    <div class="container">
        <div class="welcome-banner">
            <h2>Welcome back, <?php echo htmlspecialchars($username); ?>!</h2>
            <p>Continue your learning journey. You're doing great!</p>
        </div>

        <div class="stats">
            <div class="stat-card">
                <h3><?php echo $enrollment_count; ?></h3>
                <p>Enrolled Courses</p>
            </div>
            <div class="stat-card">
                <h3><?php echo count($all_courses); ?></h3>
                <p>Available Courses</p>
            </div>
            <div class="stat-card">
                <h3>0</h3>
                <p>Completed Courses</p>
            </div>
        </div>

        <h2 class="section-title">My Enrolled Courses</h2>
        <?php if(count($enrolled_courses) > 0): ?>
            <div class="courses-grid">
                <?php foreach($enrolled_courses as $course): ?>
                    <div class="course-card">
                        <?php if($course['image_url']): ?>
                            <img src="<?php echo htmlspecialchars($course['image_url']); ?>" alt="<?php echo htmlspecialchars($course['title']); ?>" class="course-image">
                        <?php else: ?>
                            <div class="course-image" style="background: linear-gradient(135deg, #667eea, #764ba2); display: flex; align-items: center; justify-content: center; color: white; font-size: 48px;">📚</div>
                        <?php endif; ?>
                        <div class="course-content">
                            <span class="enrolled-badge">Enrolled</span>
                            <h3 class="course-title"><?php echo htmlspecialchars($course['title']); ?></h3>
                            <div class="course-category"><?php echo htmlspecialchars($course['category']); ?></div>
                            <p class="course-description"><?php echo substr(htmlspecialchars($course['description']), 0, 100); ?>...</p>
                            <div class="course-meta">Enrolled on: <?php echo date('M d, Y', strtotime($course['enrolled_at'])); ?></div>
                            <a href="#" class="btn">Continue Learning</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <h3>You haven't enrolled in any course yet</h3>
                <p>Browse our available courses and start learning today!</p>
            </div>
        <?php endif; ?>

        <h2 class="section-title">Explore More Courses</h2>
        <div class="courses-grid">
            <?php foreach($all_courses as $course): ?>
                <div class="course-card">
                    <?php if($course['image_url']): ?>
                        <img src="<?php echo htmlspecialchars($course['image_url']); ?>" alt="<?php echo htmlspecialchars($course['title']); ?>" class="course-image">
                    <?php else: ?>
                        <div class="course-image" style="background: linear-gradient(135deg, #667eea, #764ba2); display: flex; align-items: center; justify-content: center; color: white; font-size: 48px;">📚</div>
                    <?php endif; ?>
                    <div class="course-content">
                        <h3 class="course-title"><?php echo htmlspecialchars($course['title']); ?></h3>
                        <div class="course-category"><?php echo htmlspecialchars($course['category']); ?></div>
                        <p class="course-description"><?php echo substr(htmlspecialchars($course['description']), 0, 100); ?>...</p>
                        <a href="enroll.php?course_id=<?php echo $course['id']; ?>" class="btn">Enroll Now</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>
