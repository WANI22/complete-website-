<?php
session_start();

require_once '../Config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: ../login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

$message = "";
$messageColor = "green";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['update_profile'])) {
        $new_username = trim($_POST['username']);
        $new_email = trim($_POST['email']);
        
        if (empty($new_username) || empty($new_email)) {
            $message = "All fields are required";
            $messageColor = "red";
        } elseif (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
            $message = "Invalid email format";
            $messageColor = "red";
        } else {
            // Check if username or email already exists for other users
            $checkQuery = "SELECT id FROM users WHERE (username = :username OR email = :email) AND id != :user_id";
            $checkStmt = $db->prepare($checkQuery);
            $checkStmt->bindParam(":username", $new_username);
            $checkStmt->bindParam(":email", $new_email);
            $checkStmt->bindParam(":user_id", $user_id);
            $checkStmt->execute();
            
            if ($checkStmt->rowCount() > 0) {
                $message = "Username or email already exists";
                $messageColor = "red";
            } else {
                $query = "UPDATE users SET username = :username, email = :email WHERE id = :user_id";
                $stmt = $db->prepare($query);
                $stmt->bindParam(":username", $new_username);
                $stmt->bindParam(":email", $new_email);
                $stmt->bindParam(":user_id", $user_id);
                
                if ($stmt->execute()) {
                    $_SESSION['username'] = $new_username;
                    $username = $new_username;
                    $message = "Profile updated successfully!";
                    $messageColor = "green";
                } else {
                    $message = "Error updating profile";
                    $messageColor = "red";
                }
            }
        }
    }
    
    if (isset($_POST['change_password'])) {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
            $message = "All password fields are required";
            $messageColor = "red";
        } elseif ($new_password !== $confirm_password) {
            $message = "New passwords do not match";
            $messageColor = "red";
        } elseif (strlen($new_password) < 6) {
            $message = "Password must be at least 6 characters";
            $messageColor = "red";
        } else {
            // Verify current password
            $query = "SELECT password FROM users WHERE id = :user_id";
            $stmt = $db->prepare($query);
            $stmt->bindParam(":user_id", $user_id);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (password_verify($current_password, $user['password'])) {
                $hashedPassword = password_hash($new_password, PASSWORD_DEFAULT);
                $query = "UPDATE users SET password = :password WHERE id = :user_id";
                $stmt = $db->prepare($query);
                $stmt->bindParam(":password", $hashedPassword);
                $stmt->bindParam(":user_id", $user_id);
                
                if ($stmt->execute()) {
                    $message = "Password changed successfully!";
                    $messageColor = "green";
                } else {
                    $message = "Error changing password";
                    $messageColor = "red";
                }
            } else {
                $message = "Current password is incorrect";
                $messageColor = "red";
            }
        }
    }
}

// Get user details
$query = "SELECT * FROM users WHERE id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(":user_id", $user_id);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Get enrollment count
$query = "SELECT COUNT(*) as count FROM enrollments WHERE user_id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(":user_id", $user_id);
$stmt->execute();
$enrollment_count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - KING D ACADEMY</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        body {
            background: #f5f7fa;
        }
        .navbar {
            background: linear-gradient(135deg, #20c997 0%, #0ca678 100%);
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        .navbar h1 {
            font-size: 24px;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        .nav-links a {
            color: white;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 6px;
            transition: background 0.3s;
        }
        .nav-links a:hover {
            background: rgba(255,255,255,0.2);
        }
        .nav-links .logout {
            background: #e74c3c;
        }
        .container {
            max-width: 900px;
            margin: 2rem auto;
            padding: 0 2rem;
        }
        .profile-header {
            background: linear-gradient(135deg, #20c997 0%, #0ca678 100%);
            color: white;
            padding: 2rem;
            border-radius: 15px;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 20px;
        }
        .profile-avatar {
            width: 100px;
            height: 100px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 40px;
            color: #667eea;
        }
        .profile-info h2 {
            font-size: 28px;
            margin-bottom: 5px;
        }
        .profile-info p {
            opacity: 0.9;
        }
        .stats {
            display: flex;
            gap: 20px;
            margin-bottom: 2rem;
        }
        .stat-card {
            flex: 1;
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .stat-card h3 {
            color: #667eea;
            font-size: 32px;
        }
        .form-card {
            background: white;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
        }
        .form-card h3 {
            color: #333;
            margin-bottom: 1.5rem;
            padding-bottom: 10px;
            border-bottom: 2px solid #667eea;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
        }
        .form-group input {
            width: 100%;
            padding: 12px;
            border: 2px solid #e1e1e1;
            border-radius: 8px;
            font-size: 16px;
        }
        .form-group input:focus {
            outline: none;
            border-color: #667eea;
        }
        .btn {
            padding: 12px 24px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s;
        }
        .btn:hover {
            background: #5568d3;
        }
        .message {
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .message.success {
            background: #d4edda;
            color: #155724;
        }
        .message.error {
            background: #f8d7da;
            color: #721c24;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #667eea;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <h1>KING D ACADEMY</h1>
        <div class="nav-links">
            <a href="../index.php">Home</a>
            <a href="dashboard.php">My Courses</a>
            <a href="profile.php">Profile</a>
            <a href="../logout.php" class="logout">Logout</a>
        </div>
    </nav>

    <div class="container">
        <a href="dashboard.php" class="back-link">← Back to Dashboard</a>
        
        <div class="profile-header">
            <div class="profile-avatar">👤</div>
            <div class="profile-info">
                <h2><?php echo htmlspecialchars($user['username']); ?></h2>
                <p><?php echo htmlspecialchars($user['email']); ?></p>
            </div>
        </div>

        <div class="stats">
            <div class="stat-card">
                <h3><?php echo $enrollment_count; ?></h3>
                <p>Enrolled Courses</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $user['role']; ?></h3>
                <p>Account Type</p>
            </div>
        </div>

        <?php if($message): ?>
            <div class="message <?php echo $messageColor === 'green' ? 'success' : 'error'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <div class="form-card">
            <h3>Update Profile</h3>
            <form method="POST">
                <input type="hidden" name="update_profile" value="1">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                </div>
                <button type="submit" class="btn">Update Profile</button>
            </form>
        </div>

        <div class="form-card">
            <h3>Change Password</h3>
            <form method="POST">
                <input type="hidden" name="change_password" value="1">
                <div class="form-group">
                    <label for="current_password">Current Password</label>
                    <input type="password" id="current_password" name="current_password" required>
                </div>
                <div class="form-group">
                    <label for="new_password">New Password</label>
                    <input type="password" id="new_password" name="new_password" required>
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirm New Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" required>
                </div>
                <button type="submit" class="btn">Change Password</button>
            </form>
        </div>
    </div>
</body>
</html>
