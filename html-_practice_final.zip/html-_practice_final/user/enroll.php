<?php
session_start();

require_once '../Config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: ../login.php");
    exit();
}

if (!isset($_GET['course_id']) || !is_numeric($_GET['course_id'])) {
    header("Location: dashboard.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();

$user_id = $_SESSION['user_id'];
$course_id = intval($_GET['course_id']);

// Check if course exists
$query = "SELECT * FROM courses WHERE id = :course_id";
$stmt = $db->prepare($query);
$stmt->bindParam(":course_id", $course_id);
$stmt->execute();
$course = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$course) {
    header("Location: dashboard.php");
    exit();
}

// Check if already enrolled
$query = "SELECT * FROM enrollments WHERE user_id = :user_id AND course_id = :course_id";
$stmt = $db->prepare($query);
$stmt->bindParam(":user_id", $user_id);
$stmt->bindParam(":course_id", $course_id);
$stmt->execute();

if ($stmt->rowCount() > 0) {
    // Already enrolled
    header("Location: dashboard.php?msg=already_enrolled");
    exit();
}

// Enroll in course
$query = "INSERT INTO enrollments (user_id, course_id) VALUES (:user_id, :course_id)";
$stmt = $db->prepare($query);
$stmt->bindParam(":user_id", $user_id);
$stmt->bindParam(":course_id", $course_id);

if ($stmt->execute()) {
    header("Location: dashboard.php?msg=enrolled");
    exit();
} else {
    header("Location: dashboard.php?msg=error");
    exit();
}
?>
