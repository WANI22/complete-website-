<?php
session_start();
require_once 'Config/database.php';

$is_logged_in = isset($_SESSION['user_id']);
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';
$user_role = isset($_SESSION['role']) ? $_SESSION['role'] : '';

// Get courses from database
$database = new Database();
$db = $database->getConnection();
$query = "SELECT * FROM courses ORDER BY created_at DESC LIMIT 6";
$stmt = $db->prepare($query);
$stmt->execute();
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KING D ACADEMY - Online Learning Platform</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        body {
            line-height: 1.6;
            color: #333;
        }
        
        /* Navigation */
        .navbar {
            background: linear-gradient(135deg, #20c997 0%, #0ca678 100%);
            padding: 1rem 5%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .logo {
            font-size: 28px;
            font-weight: bold;
            color: white;
            text-decoration: none;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        .nav-links a {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 8px;
            transition: all 0.3s;
        }
        .nav-links a:hover {
            background: rgba(255,255,255,0.2);
        }
        .nav-links .btn-primary {
            background: white;
            color: #20c997;
            font-weight: 600;
        }
        .nav-links .btn-primary:hover {
            background: #f0f0f0;
        }
        .user-menu {
            display: flex;
            align-items: center;
            gap: 15px;
            color: white;
        }
        .user-menu a {
            color: white;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 6px;
            background: rgba(255,255,255,0.2);
        }
        
        /* Hero Section */
        .hero {
            background: linear-gradient(135deg, #20c997 0%, #0ca678 100%);
            color: white;
            padding: 100px 5%;
            text-align: center;
            min-height: 70vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .hero-content {
            max-width: 800px;
        }
        .hero h1 {
            font-size: 56px;
            margin-bottom: 20px;
            line-height: 1.2;
        }
        .hero p {
            font-size: 20px;
            margin-bottom: 30px;
            opacity: 0.9;
        }
        .hero-buttons {
            display: flex;
            gap: 20px;
            justify-content: center;
        }
        .btn {
            padding: 15px 40px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 600;
            font-size: 16px;
            transition: all 0.3s;
        }
        .btn-white {
            background: white;
            color: #20c997;
        }
        .btn-outline {
            border: 2px solid white;
            color: white;
        }
        .btn-white:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .btn-outline:hover {
            background: white;
            color: #20c997;
        }
        
        /* Features Section */
        .features {
            padding: 80px 5%;
            background: #f8f9fa;
        }
        .section-title {
            text-align: center;
            margin-bottom: 50px;
        }
        .section-title h2 {
            font-size: 40px;
            color: #333;
            margin-bottom: 15px;
        }
        .section-title p {
            color: #666;
            font-size: 18px;
        }
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
        }
        .feature-card {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.3s;
        }
        .feature-card:hover {
            transform: translateY(-10px);
        }
        .feature-icon {
            font-size: 60px;
            margin-bottom: 20px;
        }
        .feature-card h3 {
            font-size: 24px;
            margin-bottom: 15px;
            color: #333;
        }
        .feature-card p {
            color: #666;
        }
        
        /* Courses Section */
        .courses {
            padding: 80px 5%;
        }
        .courses-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
        }
        .course-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        .course-card:hover {
            transform: translateY(-10px);
        }
        .course-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            background: linear-gradient(135deg, #20c997, #764ba2);
        }
        .course-content {
            padding: 25px;
        }
        .course-category {
            color: #20c997;
            font-weight: 600;
            font-size: 14px;
            margin-bottom: 10px;
        }
        .course-title {
            font-size: 20px;
            margin-bottom: 10px;
            color: #333;
        }
        .course-description {
            color: #666;
            margin-bottom: 15px;
            font-size: 14px;
        }
        .course-btn {
            display: inline-block;
            padding: 10px 25px;
            background: #20c997;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            transition: background 0.3s;
        }
        .course-btn:hover {
            background: #5568d3;
        }
        
        /* About Section */
        .about {
            padding: 80px 5%;
            background: linear-gradient(135deg, #20c997 0%, #0ca678 100%);
            color: white;
        }
        .about-content {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 50px;
            align-items: center;
        }
        .about-text h2 {
            font-size: 40px;
            margin-bottom: 20px;
        }
        .about-text p {
            font-size: 18px;
            margin-bottom: 20px;
            opacity: 0.9;
        }
        .about-stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }
        .stat-item {
            background: rgba(255,255,255,0.2);
            padding: 30px;
            border-radius: 15px;
            text-align: center;
        }
        .stat-item h3 {
            font-size: 40px;
            margin-bottom: 5px;
        }
        
        /* Testimonials */
        .testimonials {
            padding: 80px 5%;
            background: #f8f9fa;
        }
        .testimonials-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
        }
        .testimonial-card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        .testimonial-text {
            font-style: italic;
            color: #666;
            margin-bottom: 20px;
        }
        .testimonial-author {
            font-weight: 600;
            color: #333;
        }
        
        /* CTA Section */
        .cta {
            padding: 80px 5%;
            background: linear-gradient(135deg, #20c997 0%, #0ca678 100%);
            color: white;
            text-align: center;
        }
        .cta h2 {
            font-size: 40px;
            margin-bottom: 20px;
        }
        .cta p {
            font-size: 20px;
            margin-bottom: 30px;
            opacity: 0.9;
        }
        
        /* Footer */
        footer {
            background: #1a1a2e;
            color: white;
            padding: 60px 5% 20px;
        }
        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
            margin-bottom: 40px;
        }
        .footer-section h3 {
            font-size: 20px;
            margin-bottom: 20px;
            color: #20c997;
        }
        .footer-section p {
            color: #999;
            margin-bottom: 10px;
        }
        .footer-section a {
            color: #999;
            text-decoration: none;
            display: block;
            margin-bottom: 10px;
            transition: color 0.3s;
        }
        .footer-section a:hover {
            color: #20c997;
        }
        .footer-bottom {
            text-align: center;
            padding-top: 20px;
            border-top: 1px solid #333;
            color: #999;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .hero h1 {
                font-size: 36px;
            }
            .hero-buttons {
                flex-direction: column;
            }
            .about-content {
                grid-template-columns: 1fr;
            }
            .nav-links {
                display: none;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <a href="index.php" class="logo">KING D ACADEMY</a>
        <div class="nav-links">
            <a href="#home">Home</a>
            <a href="#courses">Courses</a>
            <a href="#about">About</a>
            <a href="#testimonials">Testimonials</a>
            <a href="teach-with-us.php">Teach with Us</a>
            
            <?php if($is_logged_in): ?>
                <div class="user-menu">
                    <span>Welcome, <?php echo htmlspecialchars($username); ?>!</span>
                    <?php if($user_role === 'admin'): ?>
                        <a href="Admin/dashboard.php">Dashboard</a>
                    <?php else: ?>
                        <a href="user/dashboard.php">My Courses</a>
                    <?php endif; ?>
                    <a href="logout.php">Logout</a>
                </div>
            <?php else: ?>
                <a href="login.php" class="btn-primary">Login</a>
                <a href="signup.php">Sign Up</a>
            <?php endif; ?>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero" id="home">
        <div class="hero-content">
            <h1>Unlock Your Potential with Online Learning</h1>
            <p>Join thousands of learners and access world-class courses from expert instructors. Start your journey today!</p>
            <div class="hero-buttons">
                <?php if(!$is_logged_in): ?>
                    <a href="signup.php" class="btn btn-white">Get Started Free</a>
                    <a href="#courses" class="btn btn-outline">Browse Courses</a>
                <?php else: ?>
                    <a href="user/dashboard.php" class="btn btn-white">Go to My Dashboard</a>
                    <a href="#courses" class="btn btn-outline">Browse Courses</a>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Popular Courses Section -->
    <section class="courses" id="courses">
        <div class="section-title">
            <h2>Popular Courses</h2>
            <p>Start learning from our most popular courses</p>
        </div>
        <div class="courses-grid">
            <?php if(count($courses) > 0): ?>
                <?php foreach($courses as $course): ?>
                    <div class="course-card">
                        <?php if($course['image_url']): ?>
                            <img src="<?php echo htmlspecialchars($course['image_url']); ?>" alt="<?php echo htmlspecialchars($course['title']); ?>" class="course-image">
                        <?php else: ?>
                            <div class="course-image" style="display: flex; align-items: center; justify-content: center; color: white; font-size: 48px;">📚</div>
                        <?php endif; ?>
                        <div class="course-content">
                            <div class="course-category"><?php echo htmlspecialchars($course['category']); ?></div>
                            <h3 class="course-title"><?php echo htmlspecialchars($course['title']); ?></h3>
                            <p class="course-description"><?php echo substr(htmlspecialchars($course['description']), 0, 100); ?>...</p>
                            <?php if($is_logged_in && $user_role !== 'admin'): ?>
                                <a href="user/enroll.php?course_id=<?php echo $course['id']; ?>" class="course-btn">Enroll Now</a>
                            <?php elseif(!$is_logged_in): ?>
                                <a href="signup.php" class="course-btn">Sign Up to Enroll</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="grid-column: 1/-1; text-align: center; padding: 40px;">
                    <h3>No courses available yet</h3>
                    <p>Check back soon for new courses!</p>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features">
        <div class="section-title">
            <h2>Why Choose Learnify?</h2>
            <p>Everything you need to succeed in your learning journey</p>
        </div>
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">🎓</div>
                <h3>Expert Instructors</h3>
                <p>Learn from industry experts with years of experience in their fields</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">📚</div>
                <h3>100+ Courses</h3>
                <p>Access hundreds of courses across various subjects and skill levels</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">⏰</div>
                <h3>Learn Anytime</h3>
                <p>Study at your own pace, anywhere, anytime - lifetime access to courses</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">📱</div>
                <h3>Mobile Friendly</h3>
                <p>Access your courses on any device - desktop, tablet, or mobile</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🏆</div>
                <h3>Certificates</h3>
                <p>Earn certificates upon completion to showcase your skills</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">💬</div>
                <h3>Community</h3>
                <p>Join a community of learners and get support from peers and instructors</p>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section class="about" id="about">
        <div class="about-content">
            <div class="about-text">
                <h2>About KING D ACADEMY</h2>
                <p>KING D ACADEMY is a leading online learning platform dedicated to providing high-quality education to learners around the world. We believe that education should be accessible to everyone, anywhere, anytime.</p>
                <p>Our mission is to empower individuals by providing them with the skills and knowledge they need to succeed in their careers and personal lives.</p>
            </div>
            <div class="about-stats">
                <div class="stat-item">
                    <h3>10K+</h3>
                    <p>Students</p>
                </div>
                <div class="stat-item">
                    <h3>100+</h3>
                    <p>Courses</p>
                </div>
                <div class="stat-item">
                    <h3>50+</h3>
                    <p>Instructors</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    <section class="testimonials" id="testimonials">
        <div class="section-title">
            <h2>What Our Students Say</h2>
            <p>Hear from our satisfied learners</p>
        </div>
        <div class="testimonials-grid">
            <div class="testimonial-card">
                <p class="testimonial-text">"Learnify has transformed my career. The courses are well-structured and the instructors are amazing!"</p>
                <p class="testimonial-author">- Sarah Johnson</p>
            </div>
            <div class="testimonial-card">
                <p class="testimonial-text">"I love the flexibility of learning at my own pace. The platform is user-friendly and the content is excellent."</p>
                <p class="testimonial-author">- Michael Chen</p>
            </div>
            <div class="testimonial-card">
                <p class="testimonial-text">"The best online learning platform I've used. Highly recommended for anyone looking to upskill!"</p>
                <p class="testimonial-author">- Emily Davis</p>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta">
        <h2>Ready to Start Learning?</h2>
        <p>Join thousands of students already learning on Learnify</p>
        <?php if(!$is_logged_in): ?>
            <a href="signup.php" class="btn btn-white">Sign Up for Free</a>
        <?php else: ?>
            <a href="user/dashboard.php" class="btn btn-white">Go to Dashboard</a>
        <?php endif; ?>
    </section>

    <!-- Footer -->
    <footer>
        <div class="footer-content">
            <div class="footer-section">
                <h3>KING D ACADEMY</h3>
                <p>Empowering learners worldwide with quality education.</p>
            </div>
            <div class="footer-section">
                <h3>Quick Links</h3>
                <a href="#home">Home</a>
                <a href="#courses">Courses</a>
                <a href="#about">About Us</a>
                <a href="teach-with-us.php">Teach with Us</a>
            </div>
            <div class="footer-section">
                <h3>Support</h3>
                <a href="#">Help Center</a>
                <a href="#">Contact Us</a>
                <a href="#">FAQ</a>
                <a href="#">Terms of Service</a>
            </div>
            <div class="footer-section">
                <h3>Contact</h3>
                <p>Email: info@learnify.com</p>
                <p>Phone: +1 234 567 890</p>
                <p>Address: 123 Learning St, Education City</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 Learnify. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
