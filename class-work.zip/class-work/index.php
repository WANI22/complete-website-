<?php
session_start();
include "connection.php";

$stmt = $conn->query("SELECT * FROM courses");
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

$isLoggedIn = isset($_SESSION['user_id']);
$isAdmin = $isLoggedIn && $_SESSION['role'] == 'admin';
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <title>Mega D&D - Online Learning Platform</title>

    <link rel="stylesheet" href="style.css" />

    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap"
      rel="stylesheet"
    />
  </head>
  <body>
    <!-- NAVBAR -->

    <header>
      <div class="container nav">
        <h2 class="logo">Mega<span>D&D</span></h2>

        <nav id="navMenu">
          <ul>
            <li><a href="#hero">Home</a></li>
            <li><a href="#courses">Courses</a></li>
            <li><a href="#blog">Blogs</a></li>
            <li><a href="#testimonials">About Us</a></li>
            <li><a href="./teachwith.php">Teach with us</a></li>
            <?php if($isLoggedIn): ?>
              <li><a href="profile.php">My Profile</a></li>
            <?php endif; ?>
          </ul>
        </nav>

        <div class="nav-buttons">
          <?php if($isLoggedIn): ?>
            <span style="margin-right: 10px;">Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</span>
            <?php if($isAdmin): ?>
              <a href="dashboard.php" class="btn">Dashboard</a>
            <?php endif; ?>
            <a href="profile.php" class="btn">Profile</a>
            <a href="logout.php" class="btn">Logout</a>
          <?php else: ?>
            <button class="login"><a href="./login.php">Log in</a></button>
            <button class="signup"><a href="./signup.php">Sign up</a></button>
          <?php endif; ?>
        </div>
        <div class="menu-toggle" onclick="toggleMenu()">☰</div>
      </div>
    </header>

    <!-- HERO -->

    <section id="hero" class="hero">
      <div class="container hero-content">
        <div class="hero-text">
          <h1>
            Learn with <span>Mega D&D</span> <br />
            the best online learning platform
          </h1>

          <p>
            Join our community of learners and start your journey towards <br />
            success with our expert-led courses and resources.
          </p>

          <a href="#courses" class="btn">Explore Our Courses</a>
        </div>

        <div class="hero-image">
          <img src="./images/python.png" />
        </div>
      </div>
    </section>

    <!-- COURSES -->

    <section id="courses" class="courses">
  <div class="container">
    <h2>Our Online Courses</h2>

    <?php if($isAdmin): ?>
    <div style="margin-bottom:20px;">
      <a href="add_course.php" class="btn">Add Course</a>
    </div>
    <?php endif; ?>

    <div class="course-grid">

    <?php foreach($courses as $row): ?>

      <div class="card">

        <h3><?php echo htmlspecialchars($row['title']); ?></h3>

        <img src="<?php echo htmlspecialchars($row['image']); ?>" />

        <p><?php echo htmlspecialchars($row['modules']); ?> Modules</p>

        <div style="margin-top:10px;">

          <?php if($isAdmin): ?>
            <a href="edit_course.php?id=<?php echo $row['id']; ?>" class="btn">Edit</a>
            <a href="delete_course.php?id=<?php echo $row['id']; ?>" class="btn" onclick="return confirm('Are you sure?')">Delete</a>
          <?php endif; ?>

          <?php if($isLoggedIn): ?>
            <a href="enroll.php?course_id=<?php echo $row['id']; ?>" class="btn">Enroll</a>
          <?php else: ?>
            <a href="login.php" class="btn">Login to Enroll</a>
          <?php endif; ?>

        </div>

      </div>

    <?php endforeach; ?>

    </div>
  </div>
</section>

    <!-- TESTIMONIAL -->

    <section id="testimonials" class="testimonials">
      <div class="container">
        <h2>What Our Students Say</h2>

        <div class="testimonial-grid">
          <div class="testimonial">
            <img src="./images/python.png" />

            <h4>Steve Smith</h4>

            <p>
              Great UI/UX course! I learned a lot from the knowledgeable
              instructors.
            </p>
          </div>

          <div class="testimonial">
            <img src="./images/python.png" />

            <h4>Kautuk Mestri</h4>

            <p>The full stack development course was amazing.</p>
          </div>

          <div class="testimonial">
            <img src="./images/python.png" />

            <h4>Devika Gada</h4>

            <p>Digital marketing course exceeded expectations.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- BLOG -->

    <section id="blog" class="blog">
      <div class="container">
        <h2>Blogs</h2>

        <div class="blog-grid">
          <div class="blog-card">
            <img src="./images/python.png" />

            <h3>Lorem ipsum dolor sit amet</h3>

          <button class="readmore"><a href="#">Watch Video</a></button> 
          </div>

          <div class="blog-card">
            <img src="./images/python.png" />

            <h3>Lorem ipsum dolor sit amet</h3>

          <button class="readmore"><a href="#">Watch Video</a></button> 

          </div>

          <div class="blog-card">
            <img src="./images/python.png" />

            <h3>Lorem ipsum dolor sit amet</h3>

                    <button class="readmore"><a href="#">Watch Video</a></button> 


          </div>
        </div>
      </div>
    </section>

    <!-- FOOTER -->

    <footer>
      <div class="container footer">
        <div>
          <h2>Mega D&D</h2>

          <p>© 2026 Mega D&D</p>
        </div>
  
        <div class="footer-links">
          <h4><a href="#hero">Home</a></h4>

          <p><a href="#courses">Courses</a></p>
          <p><a href="#blog">Blog</a></p>
          <p><a href="#testimonials">About Us</a></p>
        </div>

        <div>
          <h4>Tech on Mega D&D</h4>

          <p>Help and Support</p>
          <p>Privacy Policy</p>
          <p>Sitemap</p>
        </div>

        <div>
          <h4>Follow Us</h4>

          <p>Instagram</p>
          <p>Twitter</p>
          <p>Facebook</p>
          <p>YouTube</p>
        </div>
      </div>
    </footer>
    

    <script src="script.js"></script>
  </body>
</html>
