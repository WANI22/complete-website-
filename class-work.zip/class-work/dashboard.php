<?php
session_start();
include "connection.php";

if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

$msg = "";

// Handle course deletion
if(isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM courses WHERE id = :id");
    $stmt->execute(['id' => $id]);
    $msg = "Course deleted successfully!";
}

// Handle enrollment deletion
if(isset($_GET['delete_enrollment'])) {
    $id = $_GET['delete_enrollment'];
    $stmt = $conn->prepare("DELETE FROM enrollments WHERE id = :id");
    $stmt->execute(['id' => $id]);
    $msg = "Enrollment removed successfully!";
}

// Fetch all courses
$courses = $conn->query("SELECT * FROM courses ORDER BY id DESC");
$courseList = $courses->fetchAll(PDO::FETCH_ASSOC);

// Fetch enrollments with user and course details
$enrollments = $conn->query("
    SELECT e.id, e.enrolled_at, u.username, u.email, c.title as course_title 
    FROM enrollments e 
    JOIN users u ON e.user_id = u.id 
    JOIN courses c ON e.course_id = c.id 
    ORDER BY e.enrolled_at DESC
");
$enrollmentList = $enrollments->fetchAll(PDO::FETCH_ASSOC);

// Fetch stats
$totalCourses = count($courseList);
$stmt = $conn->query("SELECT COUNT(*) as total FROM enrollments");
$enrollmentCount = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

$stmt = $conn->query("SELECT COUNT(*) as total FROM users WHERE role = 'student'");
$studentCount = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Mega D&D</title>
    <link rel="stylesheet" href="style.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: #f5f7ff; }
        
        .admin-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        
        .admin-header h1 { font-size: 28px; }
        
        .admin-header .user-info { display: flex; align-items: center; gap: 20px; }
        .admin-header .user-info span { font-size: 16px; }
        
        .admin-header .nav-links { display: flex; gap: 15px; }
        
        .admin-header a {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .admin-header a:hover { background: rgba(255,255,255,0.3); }
        
        .container { max-width: 1200px; margin: 40px auto; padding: 0 20px; }
        
        .tabs { display: flex; gap: 10px; margin-bottom: 30px; }
        .tab-btn {
            padding: 15px 30px;
            background: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            color: #666;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: all 0.3s;
        }
        .tab-btn.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .tab-content { display: none; }
        .tab-content.active { display: block; }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }
        
        .stat-card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .stat-card h3 { color: #666; font-size: 14px; margin-bottom: 10px; text-transform: uppercase; }
        .stat-card .number { font-size: 40px; font-weight: bold; color: #667eea; }
        
        .section-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
        .section-header h2 { color: #333; font-size: 24px; }
        
        .add-course-btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 24px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 600;
            transition: transform 0.3s;
        }
        .add-course-btn:hover { transform: translateY(-2px); }
        
        .message {
            background: #d4edda;
            color: #155724;
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            border-left: 4px solid #28a745;
        }
        
        .course-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 25px;
        }
        
        .course-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        .course-card:hover { transform: translateY(-5px); }
        
        .course-card img { width: 100%; height: 180px; object-fit: cover; }
        
        .course-info { padding: 20px; }
        .course-info h3 { color: #333; margin-bottom: 10px; font-size: 18px; }
        .course-info p { color: #666; margin-bottom: 15px; }
        
        .course-actions { display: flex; gap: 10px; }
        
        .edit-btn {
            flex: 1;
            background: #4a69bd;
            color: white;
            padding: 10px;
            border-radius: 8px;
            text-align: center;
            text-decoration: none;
            font-weight: 500;
        }
        .edit-btn:hover { background: #3c55a5; }
        
        .delete-btn {
            flex: 1;
            background: #e74c3c;
            color: white;
            padding: 10px;
            border-radius: 8px;
            text-align: center;
            text-decoration: none;
            font-weight: 500;
            border: none;
            cursor: pointer;
        }
        .delete-btn:hover { background: #c0392b; }
        
        .no-courses { text-align: center; padding: 60px; background: white; border-radius: 15px; color: #666; }
        
        /* Enrollment Table Styles */
        .enrollment-table {
            width: 100%;
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        
        .enrollment-table table { width: 100%; border-collapse: collapse; }
        
        .enrollment-table th {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px;
            text-align: left;
            font-weight: 600;
        }
        
        .enrollment-table td {
            padding: 15px;
            border-bottom: 1px solid #eee;
        }
        
        .enrollment-table tr:last-child td { border-bottom: none; }
        .enrollment-table tr:hover { background: #f8f9fa; }
        
        .remove-btn {
            background: #e74c3c;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 13px;
        }
        .remove-btn:hover { background: #c0392b; }
        
        @media (max-width: 768px) {
            .admin-header { flex-direction: column; gap: 15px; text-align: center; }
            .tabs { flex-direction: column; }
            .enrollment-table { overflow-x: auto; }
        }
    </style>
</head>
<body>
    <div class="admin-header">
        <h1>🎓 Admin Dashboard</h1>
        <div class="nav-links">
            <a href="../index.php">🌐 View Site</a>
            <a href="logout.php">Logout</a>
        </div>
        <div class="user-info">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</span>
        </div>
    </div>

    <div class="container">
        <?php if($msg): ?>
            <div class="message"><?php echo $msg; ?></div>
        <?php endif; ?>

        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Courses</h3>
                <div class="number"><?php echo $totalCourses; ?></div>
            </div>
            <div class="stat-card">
                <h3>Total Enrollments</h3>
                <div class="number"><?php echo $enrollmentCount; ?></div>
            </div>
            <div class="stat-card">
                <h3>Total Students</h3>
                <div class="number"><?php echo $studentCount; ?></div>
            </div>
        </div>

        <div class="tabs">
            <button class="tab-btn active" onclick="showTab('courses')">📚 Manage Courses</button>
            <button class="tab-btn" onclick="showTab('enrollments')">👥 Manage Enrollments</button>
        </div>

        <!-- Courses Tab -->
        <div id="courses" class="tab-content active">
            <div class="section-header">
                <h2>All Courses</h2>
                <a href="add_course.php" class="add-course-btn">+ Add New Course</a>
            </div>

            <?php if(count($courseList) > 0): ?>
                <div class="course-grid">
                    <?php foreach($courseList as $course): ?>
                        <div class="course-card">
                            <img src="<?php echo htmlspecialchars($course['image']); ?>" alt="<?php echo htmlspecialchars($course['title']); ?>">
                            <div class="course-info">
                                <h3><?php echo htmlspecialchars($course['title']); ?></h3>
                                <p><?php echo htmlspecialchars($course['modules']); ?> Modules</p>
                                <div class="course-actions">
                                    <a href="edit_course.php?id=<?php echo $course['id']; ?>" class="edit-btn">Edit</a>
                                    <a href="?delete=<?php echo $course['id']; ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this course?')">Delete</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="no-courses">
                    <h3>No courses yet</h3>
                    <p>Click "Add New Course" to create your first course.</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Enrollments Tab -->
        <div id="enrollments" class="tab-content">
            <div class="section-header">
                <h2>Student Enrollments</h2>
            </div>

            <?php if(count($enrollmentList) > 0): ?>
                <div class="enrollment-table">
                    <table>
                        <thead>
                            <tr>
                                <th>Student Name</th>
                                <th>Email</th>
                                <th>Course</th>
                                <th>Enrolled Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($enrollmentList as $enrollment): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($enrollment['username']); ?></td>
                                    <td><?php echo htmlspecialchars($enrollment['email']); ?></td>
                                    <td><?php echo htmlspecialchars($enrollment['course_title']); ?></td>
                                    <td><?php echo date('M d, Y', strtotime($enrollment['enrolled_at'])); ?></td>
                                    <td>
                                        <a href="?delete_enrollment=<?php echo $enrollment['id']; ?>" class="remove-btn" onclick="return confirm('Remove this enrollment?')">Remove</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="no-courses">
                    <h3>No enrollments yet</h3>
                    <p>Students will appear here when they enroll in courses.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function showTab(tabId) {
            document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
            document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
            document.getElementById(tabId).classList.add('active');
            event.target.classList.add('active');
        }
    </script>
</body>
</html>
