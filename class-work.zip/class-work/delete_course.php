<?php
session_start();
include "connection.php";

// Check if user is logged in and is admin
if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

$id = $_GET['id'];

$stmt = $conn->prepare("DELETE FROM courses WHERE id = :id");
$stmt->execute(['id' => $id]);

header("Location: dashboard.php");
exit;
?>
