<?php
session_start();
include "connection.php";

if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

// Get user data
$stmt = $conn->prepare("SELECT * FROM users WHERE id = :id");
$stmt->execute(['id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$error = "";
$success = "";

if(isset($_POST['update'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Validation
    if(empty($username) || empty($email)) {
        $error = "Username and email are required!";
    } elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address!";
    } else {
        // Check if email is already taken by another user
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = :email AND id != :id");
        $stmt->execute(['email' => $email, 'id' => $user_id]);
        
        if($stmt->rowCount() > 0) {
            $error = "Email already in use by another account!";
        } else {
            // Update user data
            if(!empty($new_password)) {
                if(strlen($new_password) < 6) {
                    $error = "Password must be at least 6 characters!";
                } elseif($new_password !== $confirm_password) {
                    $error = "Passwords do not match!";
                } else {
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("UPDATE users SET username = :username, email = :email, password = :password WHERE id = :id");
                    $stmt->execute(['username' => $username, 'email' => $email, 'password' => $hashed_password, 'id' => $user_id]);
                    $_SESSION['username'] = $username;
                    $success = "Profile updated successfully!";
                }
            } else {
                $stmt = $conn->prepare("UPDATE users SET username = :username, email = :email WHERE id = :id");
                $stmt->execute(['username' => $username, 'email' => $email, 'id' => $user_id]);
                $_SESSION['username'] = $username;
                $success = "Profile updated successfully!";
            }
            
            // Refresh user data
            $stmt = $conn->prepare("SELECT * FROM users WHERE id = :id");
            $stmt->execute(['id' => $user_id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - Mega D&D</title>
    <link rel="stylesheet" href="style.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: #f5f7ff; min-height: 100vh; }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header h1 { font-size: 24px; }
        
        .header .nav-links { display: flex; gap: 15px; }
        
        .header a {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .header a:hover { background: rgba(255,255,255,0.3); }
        
        .container {
            max-width: 600px;
            margin: 40px auto;
            padding: 0 20px;
        }
        
        .profile-card {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }
        
        .profile-header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #eee;
        }
        
        .avatar {
            width: 100px;
            height: 100px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            font-size: 40px;
            color: white;
        }
        
        .role-badge {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            margin-top: 10px;
        }
        
        .role-admin { background: #fff3e0; color: #fb8c00; }
        .role-student { background: #e0f7fa; color: #00acc1; }
        
        .form-group { margin-bottom: 20px; }
        
        label { display: block; margin-bottom: 8px; color: #333; font-weight: 500; }
        
        input {
            width: 100%;
            padding: 14px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 15px;
        }
        
        input:focus { outline: none; border-color: #667eea; }
        
        .btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.3s;
        }
        
        .btn:hover { transform: translateY(-2px); }
        
        .error {
            background: #ffe0e0;
            color: #ff4757;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .success {
            background: #e0ffe0;
            color: #28a745;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #666;
            text-decoration: none;
        }
        
        .password-section {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 2px solid #eee;
        }
        
        .password-section h3 {
            margin-bottom: 20px;
            color: #333;
        }
        
        .note {
            font-size: 13px;
            color: #666;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>👤 My Profile</h1>
        <div class="nav-links">
            <a href="index.php">🏠 Home</a>
            <?php if($_SESSION['role'] == 'admin'): ?>
                <a href="dashboard.php">📊 Dashboard</a>
            <?php endif; ?>
            <a href="logout.php">Logout</a>
        </div>
    </div>

    <div class="container">
        <div class="profile-card">
            <div class="profile-header">
                <div class="avatar"><?php echo strtoupper(substr($user['username'], 0, 1)); ?></div>
                <h2><?php echo htmlspecialchars($user['username']); ?></h2>
                <p><?php echo htmlspecialchars($user['email']); ?></p>
                <span class="role-badge <?php echo $user['role'] == 'admin' ? 'role-admin' : 'role-student'; ?>">
                    <?php echo $user['role'] == 'admin' ? 'Instructor' : 'Student'; ?>
                </span>
            </div>
            
            <?php if($error): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if($success): ?>
                <div class="success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                </div>
                
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                </div>
                
                <button type="submit" name="update" class="btn">Update Profile</button>
            </form>
            
            <div class="password-section">
                <h3>Change Password (Optional)</h3>
                <form method="POST">
                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" name="new_password" placeholder="Enter new password">
                        <p class="note">Leave empty to keep current password</p>
                    </div>
                    
                    <div class="form-group">
                        <label>Confirm New Password</label>
                        <input type="password" name="confirm_password" placeholder="Confirm new password">
                    </div>
                    
                    <button type="submit" name="update" class="btn">Change Password</button>
                </form>
            </div>
            
            <a href="index.php" class="back-link">← Back to Home</a>
        </div>
    </div>
</body>
</html>
