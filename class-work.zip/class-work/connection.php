<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "megad";
$port = 3306;

try {
    $conn = new PDO("mysql:host=$host;dbname=$database;port=$port", $user, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

?>
