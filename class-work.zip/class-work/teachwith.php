<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MEGA D</title>
</head>
<style>
    body{
        font-family: Arial, sans-serif;
        background-image: url('https://images.unsplash.com/photo-1503676260728-1c00da094a0b');
        background-size: cover;
    }
    .container{
        width: 50%;
        margin: auto;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
        background-color: #f9f9f9;
        box-shadow: 5px 18px 10px rgba(0, 0, 0, 0.1);
    }

    .input1[type="text"], .input1[type="email"]{
        width: 96%;
        padding: 10px;
        margin: 5px 0;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

   
    
    .field{
        border: 1px solid #ccc;
        border-radius: 4px;
        padding: 10px;
    }
    h1{
        text-align: center;
        color: #333;
        font-family: 'Times New Roman', Times, serif;
        padding: 20px;
        font-size: 36px;
    }

</style>
<body>
    <h1>Teach with Us</h1><br>
    <div class="container">
        <form action="">
                <label for="name">Full Name:</label><br><br>
                <input type="text" id="name" name="name" class="input1"><br><br>
                <label for="email">Email:</label><br><br>
                <input type="text" id="email" name="email" class="input1"><br><br>
                <label for="teaching_experience">Teaching Experience:</label><br><br>
                <input type="text" id="teaching_experience" name="teaching_experience" class="input1"><br><br>
                <label for="qualifications">Qualifications:</label><br><br>
                <input type="text" id="qualifications" name="qualifications" class="input1"><br><br>
                <label for="subject">Subject To Teach:</label><br><br>
                <input type="text" id="subject" name="subject" class="input1"><br><br>

                <fieldset class="field">
                    <legend>Preferred Teaching Mode:</legend>
                    <input type="radio" id="online" name="teaching_method" value="online"><br>
                    <label for="online">Online</label><br><br>
                    <input type="radio" id="in_person" name="teaching_method" value="in_person"><br>
                    <label for="in_person">In-Person</label><br><br>

            
                </fieldset>
                <br><br>

                <input type="text" id="introduction" name="introduction" placeholder="Introduce Yourself" class="input1"><br><br>

                    <input type="text" id="description" name="description" placeholder="Brief Description About Yourself" class="input1"><br><br>

                    <button>Chose file</button> No file Chosen.<br><br>
                    

                <input type="submit" value="Submit" style="background-color: #4CAF50; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;">
                <br><br>
                <a href="index.php">Back to Home</a>

        </form>
    </div>
    
</body>
</html>