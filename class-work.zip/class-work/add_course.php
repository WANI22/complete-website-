<?php
session_start();
include "connection.php";

if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit;
}

$error = "";
$success = "";

if(isset($_POST['add'])) {
    $title = trim($_POST['title']);
    $modules = trim($_POST['modules']);
    
    if(empty($title) || empty($modules)) {
        $error = "All fields are required!";
    } else {
        $imagePath = "";
        
        if(isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $uploadDir = "uploads/";
            if(!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
            
            $fileName = time() . '_' . basename($_FILES['image']['name']);
            $targetPath = $uploadDir . $fileName;
            $imageFileType = strtolower(pathinfo($targetPath, PATHINFO_EXTENSION));
            
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            
            if(in_array($imageFileType, $allowed)) {
                if(move_uploaded_file($_FILES['image']['tmp_name'], $targetPath)) {
                    $imagePath = $targetPath;
                } else {
                    $error = "Failed to upload image!";
                }
            } else {
                $error = "Only JPG, JPEG, PNG, GIF, WEBP files are allowed!";
            }
        } else {
            $error = "Please upload a course image!";
        }
        
        if(empty($error) && !empty($imagePath)) {
            $stmt = $conn->prepare("INSERT INTO courses(title, modules, image) VALUES(:title, :modules, :image)");
            if($stmt->execute(['title' => $title, 'modules' => $modules, 'image' => $imagePath])) {
                $success = "Course added successfully!";
            } else {
                $error = "Something went wrong!";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Course - Mega D&D</title>
    <link rel="stylesheet" href="style.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { background: #f5f7ff; min-height: 100vh; display: flex; justify-content: center; align-items: center; padding: 20px; }
        .container { background: white; padding: 40px; border-radius: 15px; box-shadow: 0 10px 40px rgba(0,0,0,0.1); width: 100%; max-width: 500px; }
        h2 { color: #333; margin-bottom: 20px; text-align: center; }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 8px; color: #333; font-weight: 500; }
        input[type="text"], input[type="number"] { width: 100%; padding: 14px; border: 2px solid #e0e0e0; border-radius: 10px; font-size: 15px; }
        input:focus { outline: none; border-color: #667eea; }
        input[type="file"] { width: 100%; padding: 14px; border: 2px dashed #e0e0e0; border-radius: 10px; background: #fafafa; }
        .btn { width: 100%; padding: 14px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 10px; font-size: 16px; font-weight: 600; cursor: pointer; }
        .btn:hover { transform: translateY(-2px); }
        .error { background: #ffe0e0; color: #ff4757; padding: 12px; border-radius: 8px; margin-bottom: 20px; }
        .success { background: #e0ffe0; color: #28a745; padding: 12px; border-radius: 8px; margin-bottom: 20px; }
        .back-link { display: block; text-align: center; margin-top: 15px; color: #666; text-decoration: none; }
        .preview { width: 100%; height: 200px; object-fit: cover; border-radius: 10px; margin-top: 10px; display: none; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Add New Course</h2>
        
        <?php if($error): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if($success): ?>
            <div class="success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label>Course Title</label>
                <input type="text" name="title" placeholder="Enter course title" required>
            </div>
            
            <div class="form-group">
                <label>Number of Modules</label>
                <input type="number" name="modules" placeholder="Enter number of modules" required>
            </div>
            
            <div class="form-group">
                <label>Course Image</label>
                <input type="file" name="image" id="imageInput" accept="image/*" onchange="previewImage(event)" required>
                <img id="imagePreview" class="preview">
            </div>
            
            <button type="submit" name="add" class="btn">Add Course</button>
        </form>
        
        <a href="dashboard.php" class="back-link">← Back to Dashboard</a>
    </div>
    
    <script>
        function previewImage(event) {
            var reader = new FileReader();
            reader.onload = function() {
                var output = document.getElementById('imagePreview');
                output.src = reader.result;
                output.style.display = 'block';
            };
            reader.readAsDataURL(event.target.files[0]);
        }
    </script>
</body>
</html>
