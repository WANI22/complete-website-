<?php
session_start();
include "connection.php";

// Check if user is logged in (both students and admins can enroll)
if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user = $_SESSION['user_id'];
$course = $_GET['course_id'];

// Check if already enrolled
$stmt = $conn->prepare("SELECT * FROM enrollments WHERE user_id = :user_id AND course_id = :course_id");
$stmt->execute(['user_id' => $user, 'course_id' => $course]);

if($stmt->rowCount() > 0) {
    $msg = "You are already enrolled in this course!";
} else {
    $stmt = $conn->prepare("INSERT INTO enrollments(user_id, course_id) VALUES(:user_id, :course_id)");
    $stmt->execute(['user_id' => $user, 'course_id' => $course]);
    $msg = "You enrolled successfully!";
}

// Get course info
$stmt = $conn->prepare("SELECT * FROM courses WHERE id = :id");
$stmt->execute(['id' => $course]);
$courseInfo = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enrollment - Mega D&D</title>
    <link rel="stylesheet" href="style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .container {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            text-align: center;
            max-width: 400px;
        }
        .icon {
            font-size: 60px;
            margin-bottom: 20px;
        }
        h2 {
            color: #333;
            margin-bottom: 15px;
        }
        p {
            color: #666;
            margin-bottom: 10px;
        }
        .course-name {
            font-weight: 600;
            color: #667eea;
            margin-bottom: 25px !important;
        }
        .btn {
            display: inline-block;
            padding: 14px 30px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 10px;
            font-weight: 600;
        }
        .btn:hover {
            transform: translateY(-2px);
        }
        .success {
            background: #e0ffe0;
            color: #28a745;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .already {
            background: #fff3e0;
            color: #fb8c00;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="icon">✓</div>
        
        <?php if(strpos($msg, 'successfully') !== false): ?>
            <div class="success"><?php echo $msg; ?></div>
        <?php else: ?>
            <div class="already"><?php echo $msg; ?></div>
        <?php endif; ?>
        
        <p class="course-name"><?php echo htmlspecialchars($courseInfo['title']); ?></p>
        
        <a href="index.php" class="btn">Back to Home</a>
    </div>
</body>
</html>
