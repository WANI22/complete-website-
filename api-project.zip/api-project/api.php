<?php
// API that returns JSON data

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$method = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET';

// Sample data
$data = [

[
"userId"=>1,
"id"=>1,
"title"=>"sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
"body"=>"quia et suscipit suscipit recusandae consequuntur expedita et cum reprehenderit molestiae ut ut quas totam nostrum rerum est autem sunt rem eveniet architecto"
],

[
"userId"=>1,
"id"=>2,
"title"=>"are or make repel provide blinded except option reprehend",
"body"=>"because and undertakes takes upon the objections that follow expeditiously and when reprehends the annoyances"
],

[
"userId"=>1,
"id"=>3,
"title"=>"who is being",
"body"=>"is things in time of life sequi are nothing reprehensible pain blessed"
],

[
"userId"=>1,
"id"=>4,
"title"=>"she repels troubles as if she were exercising herself",
"body"=>"and just but what right pleasure blinded all choosing"
],

[
"userId"=>1,
"id"=>5,
"title"=>"he is blind",
"body"=>"any and often rejecting pleasure to obtain"
],

[
"userId"=>1,
"id"=>6, 
"title"=>"they don't know what they hate",
"body"=>"repudiation seeks forgiveness but others or flees"
]

];

switch($method){

case "GET":
    // Retrieve data
    echo json_encode($data);
break;

case "POST":
    $input = json_decode(file_get_contents("php://input"), true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        http_response_code(400);
        echo json_encode(["error" => "Invalid JSON"]);
        break;
    }

    echo json_encode([
        "message"=>"User created successfully",
        "data"=>$input
    ]);
break;

case "PUT":
    $input = json_decode(file_get_contents("php://input"), true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        http_response_code(400);
        echo json_encode(["error" => "Invalid JSON"]);
        break;
    }

    echo json_encode([
        "message"=>"User updated successfully",
        "data"=>$input
    ]);
break;

case "PATCH":
    $input = json_decode(file_get_contents("php://input"), true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        http_response_code(400);
        echo json_encode(["error" => "Invalid JSON"]);
        break;
    }

    echo json_encode([
        "message"=>"User partially updated successfully",
        "data"=>$input
    ]);
break;

case "DELETE":
    // Delete data
    echo json_encode([
        "message"=>"User deleted successfully"
    ]);
break;

default:
    echo json_encode([
        "message"=>"Invalid request"
    ]);
}
?>